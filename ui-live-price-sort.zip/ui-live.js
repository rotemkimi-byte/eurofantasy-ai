(() => {
  const pctText = value => {
    const n = Number(value || 0);
    return `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;
  };

  function addRefreshButton() {
    if (document.getElementById("refreshAllBtn")) return;

    const head = document.querySelector(".head");
    if (!head) return;

    const btn = document.createElement("button");
    btn.id = "refreshAllBtn";
    btn.className = "secondary";
    btn.textContent = "↻ רענן הכול";
    btn.style.fontSize = "12px";
    btn.style.padding = "8px 10px";
    btn.style.whiteSpace = "nowrap";

    btn.onclick = async () => {
      btn.disabled = true;
      btn.textContent = "מרענן…";

      const activeTab =
        document.querySelector(".tabs button.active")?.dataset?.tab;

      if (activeTab) {
        sessionStorage.setItem(
          "efa_active_tab",
          activeTab
        );
      }

      const badge =
        document.getElementById("syncBadge");

      if (badge) {
        badge.textContent = "מרענן נתונים…";
      }

      try {
        if (typeof syncOfficial === "function") {
          await Promise.race([
            syncOfficial(true),
            new Promise(resolve =>
              setTimeout(resolve, 4000)
            )
          ]);
        }
      } catch (error) {
        console.log("Official refresh:", error);
      }

      const url = new URL(window.location.href);
      url.searchParams.set("refresh", Date.now());
      window.location.replace(url.toString());
    };

    const badge =
      document.getElementById("syncBadge");

    if (badge && badge.parentNode) {
      badge.parentNode.insertBefore(btn, badge);
    } else {
      head.appendChild(btn);
    }
  }

  function getPlayerNameFromRow(tr) {
    return tr.querySelector("td.name b")
      ?.textContent
      ?.trim() || "";
  }

  function applyPriceSort() {
    if (typeof players === "undefined") return;

    const select = document.getElementById("sort");
    const tbody = document.getElementById("rows");

    if (!select || !tbody) return;
    if (!["priceDesc", "price"].includes(select.value)) return;

    const rows = [...tbody.querySelectorAll("tr")];
    if (rows.length < 2) return;

    const priceByName = new Map(
      players.map(p => [p.name, Number(p.price) || 0])
    );

    const direction = select.value === "priceDesc" ? -1 : 1;

    const sorted = [...rows].sort((a, b) => {
      const nameA = getPlayerNameFromRow(a);
      const nameB = getPlayerNameFromRow(b);
      const priceA = priceByName.get(nameA) || 0;
      const priceB = priceByName.get(nameB) || 0;

      if (priceA !== priceB) {
        return direction * (priceA - priceB);
      }

      return nameA.localeCompare(nameB);
    });

    const before = rows.map(getPlayerNameFromRow).join("|");
    const after = sorted.map(getPlayerNameFromRow).join("|");

    if (before === after) return;

    sorted.forEach(row => tbody.appendChild(row));
  }

  function setupPriceSort() {
    const select = document.getElementById("sort");
    if (!select) return;

    const oldPrice =
      select.querySelector('option[value="price"]');

    if (oldPrice) {
      oldPrice.textContent = "מחיר — מהזול ליקר";
    }

    if (
      !select.querySelector(
        'option[value="priceDesc"]'
      )
    ) {
      const desc =
        document.createElement("option");

      desc.value = "priceDesc";
      desc.textContent =
        "מחיר — מהיקר לזול";

      select.insertBefore(
        desc,
        select.firstChild
      );
    }

    // ברירת מחדל: מחיר מהיקר לזול
    select.value = "priceDesc";

    select.addEventListener(
      "input",
      () =>
        requestAnimationFrame(
          applyPriceSort
        )
    );

    // מפעיל גם את הרינדור המקורי וגם את מיון המחיר החדש
    select.dispatchEvent(
      new Event("input", { bubbles: true })
    );

    setTimeout(applyPriceSort, 50);
  }

  function enhanceMarketRows() {
    if (
      typeof players === "undefined" ||
      typeof model !== "function"
    ) {
      return;
    }

    const byName = new Map(
      players.map(p => [p.name, p])
    );

    document
      .querySelectorAll("#rows tr")
      .forEach(tr => {
        const name =
          tr.querySelector("td.name b")
            ?.textContent
            ?.trim();

        if (!name) return;

        const player = byName.get(name);
        if (!player) return;

        const cell = tr.children[7];
        if (!cell) return;

        const x = model(player);
        const value =
          Number(x.positionMatchPct || 0);

        let line =
          cell.querySelector(
            ".position-matchup-line"
          );

        if (!line) {
          line = document.createElement("div");
          line.className =
            "position-matchup-line";
          line.style.fontSize = "11px";
          line.style.fontWeight = "700";
          line.style.marginTop = "4px";
          cell.appendChild(line);
        }

        const text =
          `עמדה ${pctText(value)}`;

        if (line.textContent !== text) {
          line.textContent = text;
        }

        line.style.color =
          value >= 3
            ? "var(--accent)"
            : value <= -3
              ? "var(--bad)"
              : "var(--muted)";

        const games =
          x.positionMatchup?.sampleGames;

        line.title =
          games
            ? `מדגם: ${games} משחקים`
            : "אין מדגם נפרד לעמדה";
      });

    requestAnimationFrame(
      applyPriceSort
    );
  }

  function enhanceModal() {
    if (
      typeof players === "undefined" ||
      typeof model !== "function"
    ) {
      return;
    }

    const body =
      document.getElementById("modalBody");

    if (!body || !body.textContent) return;

    if (
      body.querySelector(
        ".position-matchup-modal"
      )
    ) {
      return;
    }

    const player =
      players.find(
        p => body.textContent.includes(p.name)
      );

    if (!player) return;

    const x = model(player);
    const value =
      Number(x.positionMatchPct || 0);

    const box =
      document.createElement("div");

    box.className =
      "notice position-matchup-modal";
    box.style.marginTop = "10px";

    const games =
      x.positionMatchup?.sampleGames;

    box.textContent =
      `מאצ׳אפ לפי עמדה (${player.pos}): ` +
      `${pctText(value)}` +
      (games
        ? ` • מדגם ${games} משחקים`
        : "");

    body.appendChild(box);
  }

  function enhanceTeamRecentStats() {
    if (
      typeof players === "undefined" ||
      typeof model !== "function"
    ) {
      return;
    }

    document
      .querySelectorAll(
        "#teamCards .miniCard"
      )
      .forEach(card => {
        const name =
          card.querySelector(
            ".sectionHead b"
          )?.textContent?.trim();

        if (!name) return;

        const player =
          players.find(
            p => p.name === name
          );

        if (!player) return;

        const x = model(player);
        const recent = x.recentForm;

        if (!recent) return;

        const chips =
          card.querySelector(".chips");

        if (!chips) return;

        let lastChip =
          chips.querySelector(
            ".recent-last-chip"
          );

        if (!lastChip) {
          lastChip =
            document.createElement(
              "span"
            );
          lastChip.className =
            "chip recent-last-chip";
          chips.appendChild(lastChip);
        }

        let avg5Chip =
          chips.querySelector(
            ".recent-avg5-chip"
          );

        if (!avg5Chip) {
          avg5Chip =
            document.createElement(
              "span"
            );
          avg5Chip.className =
            "chip recent-avg5-chip";
          chips.appendChild(avg5Chip);
        }

        const last =
          Number(
            recent.lastGame?.pir
          );

        const avg5 =
          Number(
            recent.last5?.avgPir
          );

        lastChip.textContent =
          Number.isFinite(last)
            ? `אחרון ${last.toFixed(1)} PIR`
            : "אחרון —";

        avg5Chip.textContent =
          Number.isFinite(avg5)
            ? `5 אחרונים ${avg5.toFixed(1)}`
            : "5 אחרונים —";
      });
  }

  function restoreTab() {
    const saved =
      sessionStorage.getItem(
        "efa_active_tab"
      );

    if (!saved) return;

    sessionStorage.removeItem(
      "efa_active_tab"
    );

    const button =
      document.querySelector(
        `.tabs button[data-tab="${saved}"]`
      );

    if (button) {
      button.click();
    }
  }

  function start() {
    addRefreshButton();
    setupPriceSort();
    enhanceMarketRows();
    enhanceModal();
    enhanceTeamRecentStats();

    const rows =
      document.getElementById("rows");

    if (rows) {
      new MutationObserver(() => {
        requestAnimationFrame(() => {
          enhanceMarketRows();
          applyPriceSort();
        });
      }).observe(
        rows,
        { childList: true }
      );
    }

    const teamCards =
      document.getElementById("teamCards");

    if (teamCards) {
      new MutationObserver(() => {
        requestAnimationFrame(
          enhanceTeamRecentStats
        );
      }).observe(
        teamCards,
        {
          childList: true,
          subtree: true
        }
      );
    }

    const modalBody =
      document.getElementById("modalBody");

    if (modalBody) {
      new MutationObserver(() => {
        requestAnimationFrame(
          enhanceModal
        );
      }).observe(
        modalBody,
        { childList: true }
      );
    }

    setTimeout(restoreTab, 250);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      start
    );
  } else {
    start();
  }
})();
